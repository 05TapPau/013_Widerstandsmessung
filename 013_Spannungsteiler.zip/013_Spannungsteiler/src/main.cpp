#include <Arduino.h>
#include <LiquidCrystal.h>

#define poti A0
#define Steps 4.8828125
#define Vg 5.0
#define START '#'
#define STOP '*'

const int rs = 7, en = 6, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);

byte Daten[5];
bool lesend = false, frameok = false;
double Vpot, pot, Rv, R1 = 5100.0;
unsigned long now = 0, last = 0, interv = 500;
int pos = 0, Rband1, Rband2, Rband3;

void setup()
{
  // put your setup code here, to run once:
  pinMode(poti, INPUT);
  Serial.begin(9600);
  lcd.begin(16, 2);
  lesend = false;
  frameok = false;
  pos = 0;
  /*
  lcd.print("Hallo Baen");
  lcd.setCursor(0, 1);
  lcd.print("Hallo Baen");
  */
}

/*
Uv / Rv = Ug / (Rv + R1)
*/

void R_and_LCD()
{
  pot = analogRead(poti);
  //  Serial.print(pot);

  // 1024 =~ 5mV == 4.8828mV
  Vpot = (pot * Steps) / 1000.0;
  /*
  abgegriffener Analogwert des Potis wird mit den 4,88... mv multipliziert
  und um es in Volt umzuwandeln durch 1000 geteilt
  Serial.print("  ||  ");
  Serial.print(Vpot);
  */
  //  Ohmsches Gesetzt U=R*I
  Rv = Vpot / ((Vg - Vpot) / R1);
  /*
  Serial.print("  ||  ");
  Serial.println(Rv);
  */
  lcd.setCursor(0, 0);
  lcd.print("Rv = ");
  lcd.print(Rv);
  lcd.print(" Ohm");

  lcd.setCursor(0, 1);
  lcd.print("R1 = ");
  lcd.print(R1);
  lcd.print(" Ohm");
}

void ComProt()
{
  if (Serial.available() > 0)
  {
    byte info = Serial.read();

    if (info == START && lesend == false)
    {
      pos = 0;
      // frame erkannt
      Daten[pos] = info;
      lesend = true;
    }
    else
    {
      if (lesend)
      {
        // nächstes byte speichern
        Daten[++pos] = info;
        // frame fertig?
        if (pos == 4)
        {
          // fertig gelesen
          lesend = false;
          if (info == STOP)
            frameok = true; // frame ist ok
        }
      }
    }
  }
  //  falls frame fertig gelesen, auswerung der info im frame
  if (frameok)
  {
    Rband1 = Daten[1];
    Rband2 = Daten[2];
    Rband3 = Daten[3];
    //  Rband1  Rband2,wird mal zehn hoch Rband3 berechnet
    frameok = false;
  }
}

void loop()
{
  // put your main code here, to run repeatedly:
  ComProt();

  now = millis();
  if (now - last > interv)
  {
    R1 = Rband1 * pow(10, Rband3);
    R_and_LCD();
    last = now;
  }
}